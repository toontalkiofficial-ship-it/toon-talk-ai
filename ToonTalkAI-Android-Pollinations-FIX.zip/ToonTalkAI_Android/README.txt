TOON TALK AI — ANDROID STUDIO PROJECT

This package contains the current Toon Talk AI web app inside a basic Android WebView wrapper. It is an Android project source package, NOT a compiled APK.

What is included:
- Existing Toon Talk AI HTML app as app/src/main/assets/index.html
- Android WebView launcher activity
- Internet permission for provider APIs
- Android file chooser support for selecting reference images from the phone
- Gradle Android project files

Build requirements:
- Android Studio with Android SDK Platform 35 installed
- JDK 17 or the JDK version supported by your Android Studio/Gradle setup
- Open this folder in Android Studio, allow Gradle sync, then Build > Build APK(s)

Important functionality notes:
- AI generation needs a valid Pollinations connection/API authorization in the app.
- Reference image editing works only when the authenticated image-edit endpoint is available to the account.
- This source project has not been compiled into an APK in this environment because Android SDK/Gradle build tools are not installed here. Do not treat this ZIP as an APK.
