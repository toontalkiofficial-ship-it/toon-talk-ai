package com.toontalkai.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.net.Uri;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.webkit.WebChromeClient.FileChooserParams;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQUEST = 1001;
    private static final String DEVICE_CODE_URL = "https://enter.pollinations.ai/api/device/code";
    private static final String DEVICE_TOKEN_URL = "https://enter.pollinations.ai/api/device/token";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new ToonTalkBridge(), "ToonTalkAndroid");
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (ActivityNotFoundException e) { filePathCallback = null; return false; }
                return true;
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    private final class ToonTalkBridge {
        @JavascriptInterface public void requestDeviceCode(String clientId, String callbackId) {
            try {
                JSONObject body = new JSONObject();
                body.put("client_id", clientId);
                postPollinations(DEVICE_CODE_URL, body, callbackId);
            } catch (Exception e) { sendResult(callbackId, errorJson(e)); }
        }

        @JavascriptInterface public void requestDeviceToken(String deviceCode, String callbackId) {
            try {
                JSONObject body = new JSONObject();
                body.put("device_code", deviceCode);
                postPollinations(DEVICE_TOKEN_URL, body, callbackId);
            } catch (Exception e) { sendResult(callbackId, errorJson(e)); }
        }

        private void postPollinations(String endpoint, JSONObject body, String callbackId) {
            new Thread(() -> {
                HttpURLConnection connection = null;
                try {
                    URL url = new URL(endpoint);
                    connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setConnectTimeout(15000);
                    connection.setReadTimeout(20000);
                    connection.setDoOutput(true);
                    connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                    byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
                    try (OutputStream out = connection.getOutputStream()) { out.write(bytes); }
                    int status = connection.getResponseCode();
                    InputStream stream = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
                    String response = "{}";
                    if (stream != null) {
                        try (InputStream in = stream; ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
                            byte[] chunk = new byte[4096]; int n;
                            while ((n = in.read(chunk)) != -1) buffer.write(chunk, 0, n);
                            response = buffer.toString("UTF-8");
                        }
                    }
                    JSONObject result;
                    try { result = new JSONObject(response); }
                    catch (Exception ignored) { result = new JSONObject(); result.put("error_description", response); }
                    result.put("_httpStatus", status);
                    sendResult(callbackId, result.toString());
                } catch (Exception e) { sendResult(callbackId, errorJson(e)); }
                finally { if (connection != null) connection.disconnect(); }
            }).start();
        }

        private String errorJson(Exception e) {
            JSONObject result = new JSONObject();
            try { result.put("error", "network_error"); result.put("error_description", e.getMessage() == null ? "Network request failed" : e.getMessage()); result.put("_httpStatus", 0); }
            catch (Exception ignored) { }
            return result.toString();
        }

        private void sendResult(String callbackId, String json) {
            runOnUiThread(() -> {
                if (webView == null) return;
                String script = "window.__polliNativeResult && window.__polliNativeResult(" + JSONObject.quote(callbackId) + "," + JSONObject.quote(json) + ");";
                webView.evaluateJavascript(script, null);
            });
        }

        @JavascriptInterface public void openExternalUrl(String url) {
            if (url == null || !(url.equals("https://enter.pollinations.ai/device") || url.equals("https://enter.pollinations.ai") || url.startsWith("https://enter.pollinations.ai/device?"))) return;
            runOnUiThread(() -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                catch (ActivityNotFoundException ignored) { }
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
